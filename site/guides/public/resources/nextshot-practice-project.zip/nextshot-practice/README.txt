Nextshot practice project

1. Unzip this folder in a place where your coding agent can read it.
2. Open this folder as the agent's project.
3. Open index.html in your browser.
4. Capture and mark the title, price, and Buy button with Nextshot.
5. Give the agent your three notes through the Nextshot round prompt.

Example requests:
1. Change Lemonaid to Lemonade.
2. Change $9 a cup to $3 a cup.
3. Make the Buy button larger and easier to click.

The editable page and its styles are both in index.html.
The glass illustration is lemon-glass.svg.
This is fictional demo content, with no real account or payment data.
